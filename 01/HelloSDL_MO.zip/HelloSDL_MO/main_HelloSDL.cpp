
// SDL
#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>

// standard
#include <iostream>
#include <sstream>

int main( int argc, char* args[] )
{
	//
	// 1. lépés: inicializáljuk az SDL-t
	//

	// Állítsuk be a hiba Logging függvényt.
	SDL_LogSetPriority(SDL_LOG_CATEGORY_ERROR, SDL_LOG_PRIORITY_ERROR);
	// a grafikus alrendszert kapcsoljuk csak be, ha gond van, akkor jelezzük és lépjünk ki
	if ( SDL_Init( SDL_INIT_VIDEO ) == -1 )
	{
		// irjuk ki a hibat es termináljon a program
		SDL_LogError(SDL_LOG_CATEGORY_ERROR, "[SDL initialization] Error during the SDL initialization: %s", SDL_GetError());
		return 1;
	}

	// Miután az SDL Init lefutott, kilépésnél fusson le az alrendszerek kikapcsolása.
	// Így akkor is lefut, ha valamilyen hiba folytán lépünk ki.
	std::atexit(SDL_Quit);

	// hozzuk létre az ablakunkat
	SDL_Window *win = nullptr;
	win = SDL_CreateWindow( "Hello SDL!",		// az ablak fejléce
							100,						// az ablak bal-felső sarkának kezdeti X koordinátája
							100,						// az ablak bal-felső sarkának kezdeti Y koordinátája
							800,						// ablak szélessége
							600,						// és magassága
							SDL_WINDOW_SHOWN);			// megjelenítési tulajdonságok


	// ha nem sikerült létrehozni az ablakot, akkor írjuk ki a hibát, amit kaptunk és lépjünk ki
	if (win == nullptr)
	{
		SDL_LogError(SDL_LOG_CATEGORY_ERROR, "[Window creation] Error during the SDL initialization: %s", SDL_GetError());
		return 1;
	}

	//
	// 3. lépés: hozzunk létre egy renderelőt, rajzolót
	//

	SDL_Renderer *ren = nullptr;
	ren = SDL_CreateRenderer(	win, // melyik ablakhoz rendeljük hozzá a renderert
							  -1,  // melyik indexű renderert inicializáljuk
							  // a -1 a harmadik paraméterben meghatározott igényeinknek megfelelő első renderelőt jelenti
							  SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);	// az igényeink, azaz
	// hardveresen gyorsított és vsync-et beváró
	if (ren == nullptr)
	{
		SDL_LogError( SDL_LOG_CATEGORY_ERROR, "[Renderer creation] Error during the creation of an SDL renderer: %s", SDL_GetError() );
		SDL_DestroyWindow(win);
		SDL_Quit();
		return 1;
	}



	static const Uint8 color0[ 3 ] = {   0, 255,   0 };
	static const Uint8 color1[ 3 ] = { 255,   0, 255 };

	static const SDL_Point P0 = {   0,   0 };
	static const SDL_Point P1 = { 800, 600 };

	for ( int frame_i = 0; frame_i < 100; ++frame_i )
	{
		float factor = static_cast<float>( frame_i ) / 99.0f; // Ha csak frame_i/99 -et írnánk, factor mindig 0 maradna (az utolsó frame kivételével)
		Uint8 color[ 3 ] = {}; // Törlési szín
		for ( int c_i = 0; c_i < 3; ++c_i ) // r,g,b koordinátákra számoljuk ki külön
			color[ c_i ] = static_cast<Uint8>( ( 1.0f - factor ) * color0[ c_i ] + factor * color1[ c_i ] ); // lináris interpoláció

		SDL_Point P = {
			static_cast<int>( ( 1.0f - factor ) * P0.x + factor * P1.x ),
			static_cast<int>( ( 1.0f - factor ) * P0.y + factor * P1.y )
		}; // A jelenlegi végpontja a vonalnak, lineáris interpoláció

		SDL_SetRenderDrawColor( ren, color[ 0 ], color[ 1 ], color[ 2 ], 255 ); // Törlési szín, amit most számoltunk
		SDL_RenderClear(ren); // Törlés

		SDL_SetRenderDrawColor( ren, 255, 0, 0, 255 ); // Rajzolási szín piros
		SDL_RenderDrawLine( ren, P0.x, P0.y, P.x, P.y ); // Rajzoljunk vonalat a P0 és a most számolt P között

		SDL_RenderPresent(ren); // Buffer csere
		SDL_Delay(40); // Várjunk 1/25 mp-et
	}

	// várjunk 2 másodpercet
	SDL_Delay(2000);

	//
	// 4. lépés: lépjünk ki
	// 
	SDL_DestroyRenderer( ren );
	SDL_DestroyWindow( win );

	return 0;
}
